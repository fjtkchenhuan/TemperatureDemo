package com.ys.bodymeasure;

import androidx.fragment.app.Fragment;

public class BaseFragment extends Fragment {

    public void measure(String devicePath, int deviceRate) {

    }
}
